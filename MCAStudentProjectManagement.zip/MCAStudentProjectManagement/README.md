# Student Project Management System

Simple MCA final year project built with ASP.NET Core MVC, Entity Framework Core, and SQLite database.

## Modules

- Dashboard with total students, guides, project records, and completed project count
- Student management with add, edit, delete, and search
- Faculty guide management
- Project submission tracking with guide, status, date, category, and marks
- SQLite database auto-created as `college_projects.db`

## Run In Visual Studio

1. Open `MCAStudentProjectManagement.sln`.
2. Press `F5` or click the green Run button.
3. The database is created automatically on first run.

## Run From Terminal

```powershell
dotnet run
```

Default local test URL used by Codex: `http://localhost:5123`
